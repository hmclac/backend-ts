export const config = {
  host: 'localhost',
  username: 'forums',
  password: '123',
  database: 'forums',
  port: 5000,
  frontend: 'http://localhost:3000',
  superuser_key: ';pajsjdau23j09-apcnmzxc,.'
};
